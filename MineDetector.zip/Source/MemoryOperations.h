#pragma once

#include "Main.h"

bool ReadMemoryEx(DWORD *dwAddress, uchar *pBuffer, DWORD dwSize);

