//A global header file that i use for certain cut throughs 

#ifndef MAIN_H
#define MAIN_H

#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <tlhelp32.h>

#define PROGRAM_NAME "Mine Detector"
#define inline __forceinline

//Assuming 8 bit == byte layout
#define uchar unsigned char

#define DWORD unsigned long
#define WORD  unsigned short

extern char g_Buffer[512];
extern HWND g_MainHWND;

#include "MineDetector.h"
#include "MemoryOperations.h"
#include "Utilites.h"
#include "resource.h"

extern bool NoMouseMovement;

#define MsgBox(Text) MessageBox(NULL, Text, PROGRAM_NAME, MB_OK)
#define MsgBoxError(Text) MessageBox(NULL, Text, PROGRAM_NAME, MB_OK | MB_ICONSTOP)

#define DWORDtoString(Variable, Buffer) { sprintf(Buffer, "%u", Variable); }
#define BYTEtoStringHex(Variable, Buffer) { sprintf(Buffer, "%x", Variable); }

extern void ErrorMessage(void);


#endif