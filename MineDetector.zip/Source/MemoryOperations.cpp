#include "MemoryOperations.h"

bool ReadMemoryEx(DWORD *dwAddress, uchar *pBuffer, DWORD dwSize)
{
	if(!pBuffer || !dwAddress || !dwSize)
	{
		MsgBoxError("ReadMemory: Invalid arguments passed!");
		return false;
	}

	if(!gProcessHandle)
	{	
		gProcessHandle = GetHandle_of_MineSweeper();
		if(!gProcessHandle)
		{	//HACK for dead windows
			//MsgBoxError("Couldn't obtain MineSweeper window handle!");
			return false;
		}
	}

	if(!ReadProcessMemory(gProcessHandle, dwAddress, (void *)pBuffer, (DWORD)dwSize, NULL))
	{
		if(gProcessHandle)
			MsgBoxError("Error occured with reading memory from the process");
		return false;
	}

	return true;
}
