//Win32Base code by Matthew Hannon
#include "Main.h"

char g_Buffer[512];
bool NoMouseMovement = false;

void ErrorMessage(void)
{
	char Buffer[256];

	FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, GetLastError(), 0, (LPTSTR)Buffer, 256, NULL);

	MessageBox(NULL, Buffer, PROGRAM_NAME, MB_OK);
}

uchar *bTemp;
uchar Temp = 0;

HANDLE UpdateHandle = NULL;
HANDLE ScannerThread = NULL;
DWORD ScanThreadId = 0;
HWND g_MainHWND = NULL;

DWORD WINAPI UpdateThread(LPVOID lpParameter)
{
	//Testing to see if board has changed                            
	DWORD tHeight, tWidth, tMines = 0;
	
	bool Changed = false;
	while(!Changed)
	{
		ReadMemoryEx((DWORD *)0x010056A8, (uchar *)&tHeight, 0x04);
		ReadMemoryEx((DWORD *)0x010056AC, (uchar *)&tWidth, 0x04);
		ReadMemoryEx((DWORD *)0x010056A4, (uchar *)&tMines, 0x04);

		if((tHeight != gHeight) || (tWidth != gWidth) || (tMines != gMines))
		{
			gHeight = tHeight;
			gWidth = tWidth;
			gMines = tMines;

			SetDlgItemInt(g_MainHWND, IDC_HEIGHT, gHeight, false);
			SetDlgItemInt(g_MainHWND, IDC_WIDTH, gWidth, false);
			SetDlgItemInt(g_MainHWND, IDC_MINES, gMines, false);

		}

		gProcessHandle = GetHandle_of_MineSweeper();
		if(!gProcessHandle)
		{
			Changed = true;

			SendMessage(g_MainHWND, WM_INITDIALOG, 0, 0);

			ExitThread(0);
			CloseHandle(UpdateHandle);
			UpdateHandle = NULL;
		}

		Sleep(1000);
	}

	return 1;
}

DWORD WINAPI ScanThread(LPVOID lpParameter)
{	//TODO: Add code for minesweeper exiting!
	bool Found = false;
	while(!Found)
	{
		Sleep(1000);
	
		gProcessHandle = GetHandle_of_MineSweeper();
		if(gProcessHandle)
		{
			Found = true;
			SetDlgItemText(g_MainHWND, IDC_STATUS, "MineSweeper detected!");
			EnableWindow(GetDlgItem(g_MainHWND, IDC_SOLVE0), true);
			EnableWindow(GetDlgItem(g_MainHWND, IDC_SOLVE1), true);
			EnableWindow(GetDlgItem(g_MainHWND, IDC_LABELMINES), true);

			Sleep(100);

			if(!UpdateGridData())
				MsgBoxError("Updating Grid Failed");

			if(!UpdateHandle)
				UpdateHandle = CreateThread(NULL, 0, UpdateThread, NULL, 0, NULL);
		}
	}

	//Lets not just exit the thread yet, lets use it to insure the binary stays open
	HWND hWndWindow = FindWindow(NULL, "Minesweeper");
	while(hWndWindow)
	{
		Sleep(1000);
		hWndWindow = FindWindow(NULL, "Minesweeper");
	}

	//Reached here, hWndWindow must be invalid
	SendMessage(g_MainHWND, WM_INITDIALOG, 0, 0);

	ExitThread(0);
	CloseHandle(ScannerThread);
	ScannerThread = NULL;

	//return 1;
	return 0; //return to what?
}


BOOL CALLBACK WinProc(HWND hWnd, UINT Msg, WPARAM wParam, LPARAM lParam)
{
	g_MainHWND = hWnd;
	switch(Msg)
	{
		case WM_INITDIALOG:
			if(gProcessHandle)
			{
				Sleep(1000); //For thread to safely hopefully exit
				gProcessHandle = NULL;

				SetDlgItemText(g_MainHWND, IDC_HEIGHT, "XX");
				SetDlgItemText(g_MainHWND, IDC_WIDTH, "XX");
				SetDlgItemText(g_MainHWND, IDC_MINES, "XX");

				EnableWindow(GetDlgItem(g_MainHWND, IDC_SOLVE0), false);
				EnableWindow(GetDlgItem(g_MainHWND, IDC_SOLVE1), false);
				EnableWindow(GetDlgItem(g_MainHWND, IDC_LABELMINES), false);

				SetDlgItemText(g_MainHWND, IDC_STATUS, "Waiting for MineSweeper");
			}
			if(!gProcessHandle)
			{	
				Sleep(1000);
				gProcessHandle = GetHandle_of_MineSweeper();
				if(!gProcessHandle)
				{
					SetDlgItemText(hWnd, IDC_HEIGHT, "XX");
					SetDlgItemText(hWnd, IDC_WIDTH, "XX");
					SetDlgItemText(hWnd, IDC_MINES, "XX");

					SetDlgItemText(hWnd, IDC_STATUS, "Waiting for MineSweeper");
					ScannerThread = CreateThread(NULL, 0, ScanThread, NULL, 0, &ScanThreadId);
				}
				else
				{
					SetDlgItemText(hWnd, IDC_STATUS, "MineSweeper detected!");
					EnableWindow(GetDlgItem(hWnd, IDC_SOLVE0), true);
					EnableWindow(GetDlgItem(hWnd, IDC_SOLVE1), true);
					EnableWindow(GetDlgItem(hWnd, IDC_LABELMINES), true);

					Sleep(100);

					if(!UpdateGridData())
						MsgBoxError("Updating Grid Failed");

					if(!UpdateHandle)
						UpdateHandle = CreateThread(NULL, 0, UpdateThread, NULL, 0, NULL);
				}
			}

		return TRUE;
		

		case WM_LBUTTONDOWN:
			//	SetWindowText(GetDlgItem(hWnd, IDC_EDIT1), "");

		return TRUE;


		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDC_SOLVE0:
					SolveMineSweeper(false);

					if(SolverHandle)
					{
						CloseHandle(SolverHandle);
						SolverHandle = NULL;
					}
				return TRUE;

				case IDC_SOLVE1:
					SolveMineSweeper(true);

					if(SolverHandle)
					{
						CloseHandle(SolverHandle);
						SolverHandle = NULL;
					}

				return TRUE;

				case IDC_LABELMINES:
					LabelMines();

					if(LabelHandle)
					{
						CloseHandle(LabelHandle);
						LabelHandle = NULL;
					}
					//TODOODODOD
					//Easy, can implement tommorow... fuck yeah
					//Still need to do FIndPattern for the offsets
					//And fix little errors!
					//Check OS
					//Debug
					
				//	bTemp = (uchar *)ReadCellGrid(0, 0);
					//MakeFirstSelection();
					//Temp = ReadGridIndex(8, 9); //Loop through looking for mines? but only after first click.. 
					//have continous thread updating the data after each mine is found and clicked..
					//Now trouble is calculating local and screen mouse coords... shouldn't be too difficult!
					//BYTEtoStringHex(Temp, g_Buffer);
					//SetDlgItemText(hWnd, IDC_EDIT6, g_Buffer);
					//GetWindowRect, GetClientRect... SetCursorPos.... Get valid measurements....
					
				return TRUE;

				default:
					return FALSE;

			}
		return TRUE;

		case WM_CLOSE:
			if(LabelHandle)
			{
				CloseHandle(LabelHandle);
				LabelHandle = NULL;
			}
			if(UpdateHandle)
			{
				CloseHandle(UpdateHandle);
				UpdateHandle = NULL;
			}
			if(ScannerThread)
			{
				CloseHandle(ScannerThread);
				ScannerThread = NULL;
			}
			if(gProcessHandle)
			{
				CloseHandle(gProcessHandle);
				gProcessHandle = NULL;
			}
			if(SolverHandle)
			{
				CloseHandle(SolverHandle);
				SolverHandle = NULL;
			}
			
			PostQuitMessage(0);
		return TRUE;

		case WM_DESTROY:
			if(gProcessHandle)
				CloseHandle(gProcessHandle);
			PostQuitMessage(0);
		return TRUE;
	}
	
	return FALSE;
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, char *lpszCmdLine, int nCmdShow)
{
	HICON hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_ICON0));
	SendMessage(g_MainHWND, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN), NULL, (DLGPROC)WinProc);
	//Sleep(500);
	SendMessage(g_MainHWND, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
	//MsgBox("Got this far");
	return true;
}

