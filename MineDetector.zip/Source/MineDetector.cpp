#include "MineDetector.h"

HANDLE gProcessHandle = NULL;
HWND gProcesshWnd = NULL;
HANDLE SolverHandle = NULL;
HANDLE LabelHandle = NULL;

uchar gGridData[0x360]; 

DWORD gHeight =	0;
DWORD gWidth =	0;
DWORD gMines =	0;
DWORD gMineFound = 0;
DWORD gX_Window = 0;
DWORD gY_Window = 0;

HANDLE GetHandle_of_MineSweeper()
{
	PROCESSENTRY32 ProcessInfo = FindProcess("winmine");
	if(!ProcessInfo.dwSize)
	{
		gProcessHandle = NULL;
		return (HANDLE)0;
	}

	return GetProcessHandle(ProcessInfo.th32ProcessID);
}

bool UpdateGridData()
{	
	//Get hWnd of main window
	if(!ReadMemoryEx((DWORD *)0x01005B24, (uchar *)&gProcesshWnd, 0x04))
	{
		MsgBoxError("Failed to read hWnd!");
		return false;
	}

	if(!gProcesshWnd)
	{
		MsgBoxError("Unable to get hWnd for main window!");
		return false;
	}

	//Read in essential variables
	if(!ReadMemoryEx((DWORD *)0x01005340, (uchar *)&gGridData[0], 0x360))
	{
		MsgBoxError("Failed to update grid data");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056A8, (uchar *)&gHeight, 0x04))
	{
		MsgBoxError("Failed to update height");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056AC, (uchar *)&gWidth, 0x04))
	{
		MsgBoxError("Failed to update width");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056A4, (uchar *)&gMines, 0x04))
	{
		MsgBoxError("Failed to update mines");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x01005194, (uchar *)&gMineFound, 0x04))
	{
		MsgBoxError("Failed to update mines");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056B0, (uchar *)&gX_Window, 0x04))
	{
		MsgBoxError("Failed to update x");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056B4, (uchar *)&gY_Window, 0x04))
	{
		MsgBoxError("Failed to update y");
		return false;
	}

	SetDlgItemInt(g_MainHWND, IDC_HEIGHT, gHeight, false);
	SetDlgItemInt(g_MainHWND, IDC_WIDTH, gWidth, false);
	SetDlgItemInt(g_MainHWND, IDC_MINES, gMines, false);

	return true;
}

//Note: Starts at nRow 0, and nColumn starts at 1
uchar ReadGridIndex(uchar nRow, uchar nColumn)
{
	//TODO: Add boundary detection for paramaters!
	if(gWidth && gHeight && gMines && nColumn) 
	{
		if((nRow > gHeight-1) || (nColumn > gWidth))
		{
			MsgBoxError("Passed params to ReadGridIndex aren't within boundaries!");
			return 0x00;
		}

		//This is where I should verify the integrity of the data given, IE preamble, 0x20 divisons, epilogue... but.. simple error detection will do for now
		
		uchar *pGridData = &gGridData[0];

		pGridData += 0x20;
	
		//Error detection
		if(*pGridData != 0x10)
		{
			MsgBoxError("Something is wrong with the layout!");
			return 0x00;
		}

		if(nRow != 0)
			pGridData += (nRow*0x20); //Go down a specific amount

		//More error detection
		if(((pGridData - gGridData) % 0x20) != 0)
		{
			MsgBoxError("Modulus isn't 0! Layout problem?");
			return 0x00;
		}

		pGridData += nColumn; //Move on to proper index

		return *pGridData;
	}

	MsgBoxError("Invalid memory reading");
	return 0x00;
}


bool MakeFirstSelection()
{
	// Classic Winmine client area grid offset: X=12, Y=55. Cells are 16x16.
	// Center of first cell (Row 0, Col 1) in Client Coordinates:
	// Client X = 12 + 8 = 20
	// Client Y = 55 + 8 = 63
	POINT pt = { 20, 63 };
	ClientToScreen(gProcesshWnd, &pt);

	SetCursorPos(pt.x, pt.y);

	SetForegroundWindow(gProcesshWnd);
	// Removed MOUSEEVENTF_ABSOLUTE flag to ensure it clicks exactly at current cursor pos
	mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
	Sleep(10);
	mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);

	return true;
}

bool SelectCellviaMouse(uchar Height, uchar Width)
{
	// Height is 0-indexed (Row), Width is 1-indexed (Col)
	// Client X = 12 (grid start) + 16 * (Width - 1) + 8 (center offset) = 16 * Width + 4
	// Client Y = 55 (grid start) + 16 * Height + 8 (center offset) = 16 * Height + 63
	POINT pt = { (LONG)(16 * Width + 4), (LONG)(16 * Height + 63) };
	ClientToScreen(gProcesshWnd, &pt);

	SetCursorPos(pt.x, pt.y);

	SetForegroundWindow(gProcesshWnd);
	mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);
	Sleep(10);
	mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);

	return true;
}

bool SelectCellviaRightMouse(uchar Height, uchar Width)
{
	POINT pt = { (LONG)(16 * Width + 4), (LONG)(16 * Height + 63) };
	ClientToScreen(gProcesshWnd, &pt);

	SetCursorPos(pt.x, pt.y);

	SetForegroundWindow(gProcesshWnd);
	mouse_event(MOUSEEVENTF_RIGHTDOWN, 0, 0, 0, 0);
	Sleep(10);
	mouse_event(MOUSEEVENTF_RIGHTUP, 0, 0, 0, 0);

	return true;
}

/*
DWORD WINAPI LabelThread(LPVOID Param0)
{
	// NOTE: MakeFirstSelection() has been removed from here too!

	// A simple structure to hold the coordinates of unflagged mines
	struct CellCoord {
		uchar row;
		uchar col;
	};

	while (true)
	{
		if (!UpdateGridData())
		{
			MsgBoxError("Error updating grid data in labeling thread");
			return 0;
		}

		CellCoord unflaggedMines[500];
		int mineCount = 0;
		bool hitError = false;

		// 1. Scan the board for strictly UNFLAGGED mines (0x8F)
		for (uchar iRows = 0; iRows < gHeight; iRows++)
		{
			for (uchar iCols = 1; iCols <= gWidth; iCols++)
			{
				uchar TempCell = ReadGridIndex(iRows, iCols);

				if (TempCell == Divider || TempCell == LostImage || TempCell == BadImage)
				{
					hitError = true;
					break;
				}

				// If it's 0x8F, it's a hidden mine that needs a flag.
				// (If it's 0x8E, it's already flagged, so we safely ignore it)
				if (TempCell == Mine)
				{
					unflaggedMines[mineCount].row = iRows;
					unflaggedMines[mineCount].col = iCols;
					mineCount++;
				}
			}
			if (hitError) break;
		}

		if (hitError)
		{
			break; // Game state corrupted or reset, bail out safely
		}

		// 2. If there are no unflagged mines left, our job is done!
		if (mineCount == 0)
		{
			break;
		}

		// 3. Right-click the first unflagged mine in our list
		NoMouseMovement = true;
		SelectCellviaRightMouse(unflaggedMines[0].row, unflaggedMines[0].col);

		// 4. Wait long enough for the UI to process the click and update memory
		// 15ms is fast enough to look like a rapid "zipper" effect, but slow 
		// enough that Windows won't drop the inputs.
		Sleep(15);
	}

	return 1;
}
*/

DWORD WINAPI LabelThread(LPVOID Param0)
{
	// 1. Take a single snapshot of the grid data
	if (!UpdateGridData())
	{
		MsgBoxError("Error updating grid data in labeling thread");
		return 0;
	}

	// A simple structure to hold the coordinates of unflagged mines
	struct CellCoord {
		uchar row;
		uchar col;
	};

	CellCoord unflaggedMines[500];
	int mineCount = 0;
	bool hitError = false;

	// 2. Scan the board ONCE for strictly UNFLAGGED mines (0x8F)
	for (uchar iRows = 0; iRows < gHeight; iRows++)
	{
		for (uchar iCols = 1; iCols <= gWidth; iCols++)
		{
			uchar TempCell = ReadGridIndex(iRows, iCols);

			if (TempCell == Divider || TempCell == LostImage || TempCell == BadImage)
			{
				hitError = true;
				break;
			}

			// If it's 0x8F, it's a hidden mine that needs a flag.
			if (TempCell == Mine)
			{
				unflaggedMines[mineCount].row = iRows;
				unflaggedMines[mineCount].col = iCols;
				mineCount++;
			}
		}
		if (hitError) break;
	}

	if (hitError || mineCount == 0)
	{
		return 1; // Game state corrupted, reset, or no mines found. Bail out safely.
	}

	// 3. Loop through the mapped coordinates and click them all sequentially
	for (int i = 0; i < mineCount; i++)
	{
		NoMouseMovement = true;
		SelectCellviaRightMouse(unflaggedMines[i].row, unflaggedMines[i].col);

		// 15ms works perfectly here because we no longer rely on waiting 
		// for the game's memory to update before initiating the next click.
		Sleep(15);
	}

	return 1;
}

void LabelMines()
{
	LabelHandle = CreateThread(NULL, 0, LabelThread, NULL, 0, NULL);
	if(!LabelHandle)
	{
		MsgBoxError("Unable to create thread for labeling mines!");
		return;
	}
}

bool Random0;
bool SolveMineSweeper(bool Random)
{
	Random0 = Random;
	SolverHandle = CreateThread(NULL, 0, SolverThread, NULL, 0, NULL);
	//Create thread that updates data based on a click or a needed update
	//Do random patterns with starting at a base random #, and going up until run out, if that case, just redo random

	//Need to do reset with middle face button
	return true;
}

DWORD WINAPI SolverThread(LPVOID Param0)
{
	if (Random0)
		srand(GetTickCount());

	//MakeFirstSelection();

	// FIX: Give Minesweeper time to process the click and teleport 
	// any first-click mines before we take our memory snapshot.
	Sleep(150);

	if (!UpdateGridData())
	{
		MsgBoxError("Error updating grid data in solving thread");
		return 0;
	}

	// A simple structure to hold the coordinates of remaining safe cells
	struct CellCoord {
		uchar row;
		uchar col;
	};

	// Max possible board size is 30x16 = 480 cells
	CellCoord safeCells[500];

	while (true)
	{
		int safeCount = 0;
		bool hitMineOrError = false;

		// 1. Scan the board and map all unrevealed safe cells (0x0F)
		for (uchar iRows = 0; iRows < gHeight; iRows++)
		{
			for (uchar iCols = 1; iCols <= gWidth; iCols++)
			{
				uchar TempCell = ReadGridIndex(iRows, iCols);

				if (TempCell == Divider || TempCell == LostImage || TempCell == BadImage)
				{
					hitMineOrError = true;
					break;
				}

				if (TempCell == NoMine) // 0x0F - Safe, unrevealed cell
				{
					safeCells[safeCount].row = iRows;
					safeCells[safeCount].col = iCols;
					safeCount++;
				}
			}
			if (hitMineOrError) break;
		}

		if (hitMineOrError)
		{
			// The game was lost or the board reset
			break;
		}

		// 2. If no safe cells are left in memory, we won! Break the loop cleanly.
		if (safeCount == 0)
		{
			break;
		}

		// 3. Pick a target from our list of confirmed safe cells
		CellCoord target;
		if (!Random0)
		{
			// Sequential: Just pick the first available one
			target = safeCells[0];
		}
		else
		{
			// Random: Pick a random cell strictly from the available safe list
			target = safeCells[rand() % safeCount];
		}

		// 4. Execute the click
		NoMouseMovement = true;
		SelectCellviaMouse(target.row, target.col);

		// Wait for the game's UI and memory to update (flood fills)
		Sleep(100);

		if (!UpdateGridData())
		{
			MsgBoxError("Error updating grid data in solving thread");
			return 0;
		}
	}

	return 1;
}
