#include "MineDetector.h"

HANDLE gProcessHandle = NULL;
HWND gProcesshWnd = NULL;
HANDLE SolverHandle = NULL;
HANDLE LabelHandle = NULL;

uchar gGridData[0x360]; 

DWORD gHeight =	0;
DWORD gWidth =	0;
DWORD gMines =	0;
DWORD gMineFound = 0;
DWORD gX_Window = 0;
DWORD gY_Window = 0;

HANDLE GetHandle_of_MineSweeper()
{
	PROCESSENTRY32 ProcessInfo = FindProcess("winmine");
	if(!ProcessInfo.dwSize)
	{
		gProcessHandle = NULL;
		return (HANDLE)0;
	}

	return GetProcessHandle(ProcessInfo.th32ProcessID);
}

bool UpdateGridData()
{	
	//Get hWnd of main window
	if(!ReadMemoryEx((DWORD *)0x01005B24, (uchar *)&gProcesshWnd, 0x04))
	{
		MsgBoxError("Failed to read hWnd!");
		return false;
	}

	if(!gProcesshWnd)
	{
		MsgBoxError("Unable to get hWnd for main window!");
		return false;
	}

	//Read in essential variables
	if(!ReadMemoryEx((DWORD *)0x01005340, (uchar *)&gGridData[0], 0x360))
	{
		MsgBoxError("Failed to update grid data");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056A8, (uchar *)&gHeight, 0x04))
	{
		MsgBoxError("Failed to update height");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056AC, (uchar *)&gWidth, 0x04))
	{
		MsgBoxError("Failed to update width");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056A4, (uchar *)&gMines, 0x04))
	{
		MsgBoxError("Failed to update mines");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x01005194, (uchar *)&gMineFound, 0x04))
	{
		MsgBoxError("Failed to update mines");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056B0, (uchar *)&gX_Window, 0x04))
	{
		MsgBoxError("Failed to update x");
		return false;
	}
	if(!ReadMemoryEx((DWORD *)0x010056B4, (uchar *)&gY_Window, 0x04))
	{
		MsgBoxError("Failed to update y");
		return false;
	}

	SetDlgItemInt(g_MainHWND, IDC_HEIGHT, gHeight, false);
	SetDlgItemInt(g_MainHWND, IDC_WIDTH, gWidth, false);
	SetDlgItemInt(g_MainHWND, IDC_MINES, gMines, false);

	return true;
}

//Note: Starts at nRow 0, and nColumn starts at 1
uchar ReadGridIndex(uchar nRow, uchar nColumn)
{
	//TODO: Add boundary detection for paramaters!
	if(gWidth && gHeight && gMines && nColumn) 
	{
		if((nRow > gHeight-1) || (nColumn > gWidth))
		{
			MsgBoxError("Passed params to ReadGridIndex aren't within boundaries!");
			return 0x00;
		}

		//This is where I should verify the integrity of the data given, IE preamble, 0x20 divisons, epilogue... but.. simple error detection will do for now
		
		uchar *pGridData = &gGridData[0];

		pGridData += 0x20;
	
		//Error detection
		if(*pGridData != 0x10)
		{
			MsgBoxError("Something is wrong with the layout!");
			return 0x00;
		}

		if(nRow != 0)
			pGridData += (nRow*0x20); //Go down a specific amount

		//More error detection
		if(((pGridData - gGridData) % 0x20) != 0)
		{
			MsgBoxError("Modulus isn't 0! Layout problem?");
			return 0x00;
		}

		pGridData += nColumn; //Move on to proper index

		return *pGridData;
	}

	MsgBoxError("Invalid memory reading");
	return 0x00;
}

//Offsets from top/left (0,0) are about 99-101 for Y and 10-13 for X
bool MakeFirstSelection()
{
	//Simulate click on first cell (top left)
	//12 102 about a good approximation
	RECT Rect;
	GetWindowRect(gProcesshWnd, &Rect);
	Rect.top += (102+7); //16x16 px cells
	Rect.left += (12+(7));

	SetCursorPos(Rect.left, Rect.top);

	SetForegroundWindow(gProcesshWnd);
	mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN, (DWORD)0, (DWORD)0, 0, 0);
	Sleep(10);
	mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTUP, (DWORD)0, (DWORD)0, 0, 0);

	return true;
}

bool SelectCellviaMouse(uchar Height, uchar Width)
{
	RECT Rect;
	GetWindowRect(gProcesshWnd, &Rect);
	Rect.top += (102+(16*(Height+1))); //16x16 px cells
	Rect.left += (12+(16*Width));

	SetCursorPos(Rect.left, Rect.top);
	
	//Click it!
	SetForegroundWindow(gProcesshWnd);
	mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTDOWN, (DWORD)0, (DWORD)0, 0, 0);
	Sleep(10);
	mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_LEFTUP, (DWORD)0, (DWORD)0, 0, 0);

	return true;
}

bool SelectCellviaRightMouse(uchar Height, uchar Width)
{
	RECT Rect;
	GetWindowRect(gProcesshWnd, &Rect);
	Rect.top += (102+(16*(Height+1))); //16x16 px cells
	Rect.left += (12+(16*Width));

	SetCursorPos(Rect.left, Rect.top);
	
	//Click it!
	SetForegroundWindow(gProcesshWnd);
	mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTDOWN, (DWORD)0, (DWORD)0, 0, 0);
	Sleep(10);
	mouse_event(MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_RIGHTUP, (DWORD)0, (DWORD)0, 0, 0);

	return true;
}


DWORD WINAPI LabelThread(LPVOID Param0)
{
	MakeFirstSelection();
	if(!UpdateGridData())
	{
		MsgBoxError("Error updating grid data in solving thread");
		return 0;
	}

	uchar TempCell = NULL;
	DWORD tCounter = 0;

Restart1:
	while((gMines - tCounter) > 0) //Go until all mines gone!
	{
		for(uchar iRows = 0; iRows < gHeight; iRows++)
		{
			for(uchar iCols = 1; iCols <= gWidth; iCols++)
			{
				TempCell = ReadGridIndex(iRows, iCols);

				switch(TempCell)
				{
					case Divider: 
					case LostImage:
					case BadImage: 
						goto Restart1; //For possible mouse variations
					break;

					case NoMine:
						continue;
					break;

					case Mine:
						//Found a mine
						//We need to label it now
						NoMouseMovement = true;

						SelectCellviaRightMouse(iRows, iCols);
						tCounter++; //One mine labeled

						Sleep(1); //Delay for labeling mines

						if(!UpdateGridData())
						{
							MsgBoxError("Error updating grid data in solving thread");
							return 0;
						}

					break;

					default: //Many of other values (IE 0x4X, etc)
						continue;
				}
			}
		}
	}

	return 1;
}


void LabelMines()
{
	LabelHandle = CreateThread(NULL, 0, LabelThread, NULL, 0, NULL);
	if(!LabelHandle)
	{
		MsgBoxError("Unable to create thread for labeling mines!");
		return;
	}
}

bool Random0;
bool SolveMineSweeper(bool Random)
{
	Random0 = Random;
	SolverHandle = CreateThread(NULL, 0, SolverThread, NULL, 0, NULL);
	//Create thread that updates data based on a click or a needed update
	//Do random patterns with starting at a base random #, and going up until run out, if that case, just redo random

	//Need to do reset with middle face button
	return true;
}

DWORD WINAPI SolverThread(LPVOID Param0)
{
	MakeFirstSelection();
	if(!UpdateGridData())
	{
		MsgBoxError("Error updating grid data in solving thread");
		return 0;
	}

	uchar TempCell = NULL;
	if(!Random0)
	{
start1:
		while((gMines - gMineFound) < gMines) //Does this only do anything at the end because of nested for loop?
		{
			for(uchar iRows = 0; iRows < gHeight; iRows++)
			{
				for(uchar iCols = 1; iCols <= gWidth; iCols++)
				{
					TempCell = ReadGridIndex(iRows, iCols);

					switch(TempCell)
					{
						case Divider:
						case LostImage:
						case BadImage: //TODO: Just reset the board in these cases.
							//MsgBoxError("Symbol discovered that shouldnt be there, bad news...");
							goto start1; //Purpose: Allows a tad bit of mouse movement during procedure.
							//We always could decrease delay and no problem, but hell, looks look good...
						break;

						case Mine:
							//Found a mine, lets avoid it!

						break;


						case NoMine:
							//Found a safe cell, lets click it!
							NoMouseMovement = true;
			
							SelectCellviaMouse(iRows, iCols);
							Sleep(10);

							if(!UpdateGridData())
							{
								MsgBoxError("Error updating grid data in solving thread");
								return 0;
							}

						break;


						default: //Many of other values (IE 0x4X, etc)
							continue;
					}
				}
			}
		}
	}
	else
	{	//Random selected
		srand(GetTickCount());

		uchar tHeight = 0;
		uchar tWidth = 0;
		unsigned int tCounter = 0; 
start0:
		while((((gHeight*gWidth)-gMines) - tCounter) > 0) //Go until all mines gone!
		{
			tHeight = (uchar)(rand() % gHeight); //??will it generate 0?

			tWidth = uchar(rand() % gWidth+1);
			if(tWidth == 0)
				tWidth++;
				
			TempCell = ReadGridIndex(tHeight, tWidth);

			switch(TempCell)
			{
				case Divider:
				case LostImage:
				case BadImage: //TODO: Just reset the board in these cases.
					//MsgBoxError("Symbol discovered that shouldnt be there, bad news...");
					goto start0; //Lets see difference of mouse deltas
				break;

				case Mine:
					//Found a mine, lets avoid it!

				break;

				case NoMine:
					//Found a safe cell, lets click it!
					NoMouseMovement = true;
	
					SelectCellviaMouse(tHeight, tWidth);
					tCounter++;

					Sleep(150);

					if(!UpdateGridData())
					{
						MsgBoxError("Error updating grid data in solving thread");
						return 0;
					}

				break;

				default: //Many of other values (IE 0x4X, etc)
					continue;
			}

		}


	}

	return 1;
}
