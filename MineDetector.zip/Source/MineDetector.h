#pragma once

#include "Main.h"

//TODO:
//1) Do PatternSearch for offsets
//2) Add more randomness
//3) Fix little bugs that occur during debugging
//4) Detect error better, and quicker, 0xCC.
//5) Right aftter app closes, gProcessHandle should be invalid!

#define Divider		0x10
#define Mine		0x8F
#define NoMine		0x0F
#define MineImage	0x8E
#define LostImage	0x8A
#define MineSet		0x80  //Figure me out again..
#define BadImage	0xCC //CC int 3, programmer humor is humerous

HANDLE GetHandle_of_MineSweeper();
//TODO: Get address offsets through pattern searching!

bool UpdateGridData();
uchar ReadGridIndex(uchar nRow, uchar nColumn);

bool MakeFirstSelection();
bool SelectCellviaMouse(uchar Height, uchar Width);
bool SelectCellviaRightMouse(uchar Height, uchar Width);
void LabelMines();

extern HANDLE LabelHandle;
extern HANDLE SolverHandle;
bool SolveMineSweeper(bool Random);
DWORD WINAPI SolverThread(LPVOID lpParameter);

//Make sure to fill in with real values from minesweeper process!
extern DWORD gHeight;
extern DWORD gWidth;
extern DWORD gMines;
extern DWORD gMineFound;
extern DWORD gX_Window;
extern DWORD gY_Window;


extern HWND gProcesshWnd;
extern HANDLE gProcessHandle;


//Summary of grid layout
/* Note: Some information can be inaccurate
--Offset 0x00 -> 0x360 (allocated) 0x340 (26 blocks of 0x20 a piece)
First fill 0x00 -> 0xWidth+0x02 (if not max size) with 0x10's, then if not full 0x20 block, pad with 0x0F's (although, should have already been done..)
Second, make divisions with 0x10 as borders with the width cells inbetween, pad to remaining 0x20 block if required.
Repeat second for all height, pad rest if needed
Third, make epilogue with width as in the first step.(width+2) reason for +2 is so board divides properly for memory layout (0x20 blocks)
Pad with 0x0F's until 0x340 address
Some grid hex values:

===Dividers
0x10 == Dividers based on width

===How many mines in proximity
0x40 == BoxNone
0x41 == BoxNum.1.
0x42 -> 0x4N == BoxNum.N.

===Unpleasent mine events
0xCC == Cell_MineBust_Selected

===E and D bytes are preset images, the 8 and 0 bytes are just the classifcation of object, perhaps...
0x8F == MineReal yet uncovered
0x8E == MineImage
0x8D == MineQuestion
0x8A == MineShown_Bust
0x80 == MineSet

0x0F == Box_Filler_Nothing(NoMine)
0x0E == Box_MineImage
0x0D == Box_MineQuestion
*/

extern uchar gGridData[0x360]; //864 bytes


