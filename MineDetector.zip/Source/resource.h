//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MetalDetector.rc
//
#define IDD_DIALOG1                     101
#define IDD_MAIN                        101
#define IDI_ICON4                       105
#define IDI_ICON0                       105
#define IDC_BUTTON1                     1001
#define IDC_LABELMINES                  1001
#define IDC_SOLVE0                      1002
#define IDC_SOLVE1                      1003
#define IDC_STATUS                      1005
#define IDC_HEIGHT                      1006
#define IDC_WIDTH                       1007
#define IDC_MINES                       1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
