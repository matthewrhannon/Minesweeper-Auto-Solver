#include "Utilites.h"

//I didn't write this function
void wtoc(CHAR* Dest, const WCHAR* Source)
{
	int i = 0;

	while(Source[i] != '\0')
	{
		Dest[i] = (CHAR)Source[i];
		++i;
	}
}

HANDLE GetProcessHandle(DWORD Pid)
{
	HANDLE tHandle = NULL;
	tHandle = OpenProcess(PROCESS_ALL_ACCESS, false, Pid);

	if(!tHandle)
	{
		MsgBoxError("Unable to open process from Pid");
		return (HANDLE)0;
	}

	return tHandle;
}


//Note: return is invalid if .dwSize = 0
PROCESSENTRY32 FindProcess(char *strName)
{
	PROCESSENTRY32 tPe, tPe1;
	tPe.dwSize = sizeof(PROCESSENTRY32);
	tPe1.dwSize = 0;

	HANDLE hSnapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	if(hSnapshot == INVALID_HANDLE_VALUE)
	{
		MsgBoxError("Couldnt create process snapshot!");
		return tPe1;
	}

	if(!Process32First(hSnapshot, &tPe))
	{
		MsgBoxError("Error obtaining first process structure!");
		CloseHandle(hSnapshot);

		return tPe1;
	}

	if(!strstr(tPe.szExeFile, strName))
	{
		do
		{
			if(strstr(tPe.szExeFile, strName))
			{
				CloseHandle(hSnapshot);
				return tPe;
			}

		} while(Process32Next(hSnapshot, &tPe));
	}
	else
	{
		CloseHandle(hSnapshot);
		return tPe;
	}

	//Reached here, not found
	CloseHandle(hSnapshot);
	return tPe1;
}

/*
BOOL GetProcessList( )
{
  HANDLE hProcessSnap;
  HANDLE hProcess;
  PROCESSENTRY32 pe32;
  DWORD dwPriorityClass;

  // Take a snapshot of all processes in the system.
  hProcessSnap = CreateToolhelp32Snapshot( TH32CS_SNAPPROCESS, 0 );
  if( hProcessSnap == INVALID_HANDLE_VALUE )
  {
    printError( TEXT("CreateToolhelp32Snapshot (of processes)") );
    return( FALSE );
  }

  // Set the size of the structure before using it.
  pe32.dwSize = sizeof( PROCESSENTRY32 );

  // Retrieve information about the first process,
  // and exit if unsuccessful
  if( !Process32First( hProcessSnap, &pe32 ) )
  {
    printError( TEXT("Process32First") ); // show cause of failure
    CloseHandle( hProcessSnap );          // clean the snapshot object
    return( FALSE );
  }

  // Now walk the snapshot of processes, and
  // display information about each process in turn
  do
  {
    printf( "\n\n=====================================================" );
    _tprintf( TEXT("\nPROCESS NAME:  %s"), pe32.szExeFile );
    printf( "\n-----------------------------------------------------" );

    // Retrieve the priority class.
    dwPriorityClass = 0;
    hProcess = OpenProcess( PROCESS_ALL_ACCESS, FALSE, pe32.th32ProcessID );
    if( hProcess == NULL )
      printError( TEXT("OpenProcess") );
    else
    {
      dwPriorityClass = GetPriorityClass( hProcess );
      if( !dwPriorityClass )
        printError( TEXT("GetPriorityClass") );
      CloseHandle( hProcess );
    }

    printf( "\n  Process ID        = 0x%08X", pe32.th32ProcessID );
    printf( "\n  Thread count      = %d",   pe32.cntThreads );
    printf( "\n  Parent process ID = 0x%08X", pe32.th32ParentProcessID );
    printf( "\n  Priority base     = %d", pe32.pcPriClassBase );
    if( dwPriorityClass )
      printf( "\n  Priority class    = %d", dwPriorityClass );

    // List the modules and threads associated with this process
    ListProcessModules( pe32.th32ProcessID );
    ListProcessThreads( pe32.th32ProcessID );

  } while( Process32Next( hProcessSnap, &pe32 ) );

  CloseHandle( hProcessSnap );
  return( TRUE );
}


BOOL ListProcessModules( DWORD dwPID )
{
  HANDLE hModuleSnap = INVALID_HANDLE_VALUE;
  MODULEENTRY32 me32;

  // Take a snapshot of all modules in the specified process.
  hModuleSnap = CreateToolhelp32Snapshot( TH32CS_SNAPMODULE, dwPID );
  if( hModuleSnap == INVALID_HANDLE_VALUE )
  {
    printError( TEXT("CreateToolhelp32Snapshot (of modules)") );
    return( FALSE );
  }

  // Set the size of the structure before using it.
  me32.dwSize = sizeof( MODULEENTRY32 );

  // Retrieve information about the first module,
  // and exit if unsuccessful
  if( !Module32First( hModuleSnap, &me32 ) )
  {
    printError( TEXT("Module32First") );  // show cause of failure
    CloseHandle( hModuleSnap );           // clean the snapshot object
    return( FALSE );
  }

  // Now walk the module list of the process,
  // and display information about each module
  do
  {
    _tprintf( TEXT("\n\n     MODULE NAME:     %s"),   me32.szModule );
    _tprintf( TEXT("\n     Executable     = %s"),     me32.szExePath );
    printf( "\n     Process ID     = 0x%08X",         me32.th32ProcessID );
    printf( "\n     Ref count (g)  = 0x%04X",     me32.GlblcntUsage );
    printf( "\n     Ref count (p)  = 0x%04X",     me32.ProccntUsage );
    printf( "\n     Base address   = 0x%08X", (DWORD) me32.modBaseAddr );
    printf( "\n     Base size      = %d",             me32.modBaseSize );

  } while( Module32Next( hModuleSnap, &me32 ) );

  CloseHandle( hModuleSnap );
  return( TRUE );
}

BOOL ListProcessThreads( DWORD dwOwnerPID ) 
{ 
  HANDLE hThreadSnap = INVALID_HANDLE_VALUE; 
  THREADENTRY32 te32; 
 
  // Take a snapshot of all running threads  
  hThreadSnap = CreateToolhelp32Snapshot( TH32CS_SNAPTHREAD, 0 ); 
  if( hThreadSnap == INVALID_HANDLE_VALUE ) 
    return( FALSE ); 
 
  // Fill in the size of the structure before using it. 
  te32.dwSize = sizeof(THREADENTRY32); 
 
  // Retrieve information about the first thread,
  // and exit if unsuccessful
  if( !Thread32First( hThreadSnap, &te32 ) ) 
  {
    printError( TEXT("Thread32First") ); // show cause of failure
    CloseHandle( hThreadSnap );          // clean the snapshot object
    return( FALSE );
  }

  // Now walk the thread list of the system,
  // and display information about each thread
  // associated with the specified process
  do 
  { 
    if( te32.th32OwnerProcessID == dwOwnerPID )
    {
      printf( "\n\n     THREAD ID      = 0x%08X", te32.th32ThreadID ); 
      printf( "\n     Base priority  = %d", te32.tpBasePri ); 
      printf( "\n     Delta priority = %d", te32.tpDeltaPri ); 
    }
  } while( Thread32Next(hThreadSnap, &te32 ) ); 

  CloseHandle( hThreadSnap );
  return( TRUE );
}

*/
