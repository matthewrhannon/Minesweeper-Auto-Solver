#pragma once

#include "Main.h"

void wtoc(CHAR* Dest, const WCHAR* Source);
PROCESSENTRY32 FindProcess(char *strName);

HANDLE GetProcessHandle(DWORD Pid);